/**
 * BytePrinter v4.1.0 - Windows & Mac Compatible
 *
 * Uses PowerShell on Windows and CUPS (lp) on Mac/Linux.
 * Also serves HTTPS so production HTTPS pages can reach it.
 *
 * Endpoints:
 *   GET  /status  → { connected, printerName, platform }
 *   POST /print   → { success } (body: { order, token })
 */

const express = require('express');
const cors = require('cors');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync, exec } = require('child_process');
const { formatReceiptText, formatReceiptRaw, formatReportText, formatReportRaw } = require('./receipt');

const app = express();
const HTTP_PORT = 9100;
const PHYSICAL_PRINT_DELAY_MS = 2000; // Delay to allow thermal printer to finish

// Robust Windows check
const isWindows = os.platform() === 'win32' || process.platform === 'win32';

// ── STATE ──────────────────────────────────────────────────────────
let printerName = null;
let isConnected = false;

// ── WINDOWS DETECTION (PURE POWERSHELL) ───────────────────────────
function detectWindowsPrinter() {
  try {
    const output = execSync(
      'powershell -Command "Get-Printer | Select-Object -ExpandProperty Name"',
      { encoding: 'utf-8' }
    );

    const printers = output
      .split('\n')
      .map(p => p.trim())
      .filter(p =>
        p &&
        !p.toLowerCase().includes('pdf') &&
        !p.toLowerCase().includes('onenote') &&
        !p.toLowerCase().includes('microsoft')
      );

    if (printers.length > 0) {
      printerName = printers[0];
      isConnected = true;
      console.log(`✅ Windows printer detected: ${printerName}`);
    } else {
      printerName = null;
      isConnected = false;
      console.log('⚠️ No Windows thermal/POS printer found');
    }
  } catch (err) {
    console.log('⚠️ PowerShell detection failed:', err.message);
    isConnected = false;
  }
}

// ── MAC/LINUX DETECTION (CUPS) ────────────────────────────────────
function detectMacPrinter() {
  try {
    const output = execSync('lpstat -d 2>/dev/null', { encoding: 'utf-8' }).trim();
    const match = output.match(/system default destination:\s*(.+)/);

    if (match) {
      printerName = match[1].trim();
      isConnected = true;
      console.log(`✅ Mac printer detected: ${printerName}`);
    } else {
      isConnected = false;
      console.log('⚠️ No Mac printer detected via lpstat');
    }
  } catch (err) {
    console.log('⚠️ CUPS not available on this system');
    isConnected = false;
  }
}

// ── UNIVERSAL DETECTION ───────────────────────────────────────────
function detectPrinter() {
  if (isWindows) {
    detectWindowsPrinter();
  } else {
    detectMacPrinter();
  }
}

// ── WINDOWS PRINTING (VIA POWERSHELL RAW PRINT) ───────────────────
async function printViaWindows(rawData, token) {
  const tmpFile = path.join(os.tmpdir(), `receipt_${token}.bin`);
  const buffer = Buffer.from(rawData.join(''), 'binary');
  fs.writeFileSync(tmpFile, buffer);

  const scriptPath = path.join(__dirname, 'scripts', 'raw-print.ps1');

  return new Promise((resolve, reject) => {
    // Escaping the printer name for PowerShell
    const cmd = `powershell -ExecutionPolicy Bypass -File "${scriptPath}" -printerName "${printerName}" -filePath "${tmpFile}"`;

    exec(cmd, (err, stdout, stderr) => {
      // Cleanup
      try { fs.unlinkSync(tmpFile); } catch {}

      if (err) {
        console.error('❌ PowerShell Print Error:', stderr || stdout || err.message);
        reject(new Error(stderr || stdout || err.message));
      } else {
        console.log(`✅ ${stdout.trim()}`);
        resolve(stdout.trim());
      }
    });
  });
}

// ── MAC PRINTING (VIA CUPS) ────────────────────────────────────────
function printViaCUPS(rawData, token) {
  return new Promise((resolve, reject) => {
    const tmpFile = path.join(os.tmpdir(), `receipt_${token}.bin`);
    const buffer = Buffer.from(rawData.join(''), 'binary');
    fs.writeFileSync(tmpFile, buffer);

    const cmd = `lp -d "${printerName}" -o raw "${tmpFile}"`;
    exec(cmd, (err, stdout, stderr) => {
      try { fs.unlinkSync(tmpFile); } catch {}
      if (err) reject(new Error(stderr || err.message));
      else resolve(stdout.trim());
    });
  });
}

// ── HTTP SERVER ONLY ───────────────────────────────────────────────────
// Robust CORS & Private Network Access (PNA) middleware
app.use((req, res, next) => {
  const origin = req.headers.origin;
  
  // Support specific origins for stricter loopback access
  if (origin && (origin.includes('aromadhaba.in') || origin.includes('localhost'))) {
    res.header('Access-Control-Allow-Origin', origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }

  // Mandatory for Chrome's Private Network Access preflights (OPTIONS)
  // Also keeps loopback access alive for GET/POST
  res.header('Access-Control-Allow-Private-Network', 'true');
  res.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  res.set('Access-Control-Max-Age', '86400'); // Cache preflight for 24h

  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

app.use(express.json());

// ── ROUTES ────────────────────────────────────────────────────────

app.get('/status', (req, res) => {
  // Only re-detect if we haven't found a printer or if explicitly requested
  if (!isConnected || !printerName || req.query.refresh === 'true') {
    detectPrinter();
  }

  res.json({
    connected: isConnected,
    printerName: printerName || null,
    username: os.userInfo().username,
    server: 'byte-printer',
    version: '4.1.0',
    platform: os.platform(),
  });
});

app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

app.post('/print', async (req, res) => {
  const { order, token } = req.body;

  if (!order || !token) {
    return res.status(400).json({ success: false, error: 'Missing order or token' });
  }

  const text = formatReceiptText(order, token);
  console.log('\n📄 RECEIPT #' + token + ':');
  console.log(text);

  if (!isConnected || !printerName) {
    return res.json({
      success: true,
      printed: false,
      message: 'No printer — receipt logged to console',
      receipt: text,
    });
  }

  try {
    const rawData = formatReceiptRaw(order, token);

    if (isWindows) {
      await printViaWindows(rawData, token);
    } else {
      await printViaCUPS(rawData, token);
    }


    console.log(`🖨️ Printed #${token} → ${printerName}`);

    // Wait for physical printing to complete to improve UX
    await new Promise(r => setTimeout(r, PHYSICAL_PRINT_DELAY_MS));

    res.json({ success: true, printed: true });
  } catch (err) {
    console.error('❌ Print failed:', err.message);
    res.status(500).json({
      success: false,
      error: err.message,
      receipt: text,
    });
  }
});

// ── PRINT REPORT ─────────────────────────────────────────────────
app.post('/print-report', async (req, res) => {
  const reportData = req.body;

  if (!reportData || !reportData.summary) {
    return res.status(400).json({ success: false, error: 'Missing report data' });
  }

  const token = `RPT-${Date.now()}`;
  const text = formatReportText(reportData);
  console.log('\n📊 REPORT:');
  console.log(text);

  if (!isConnected || !printerName) {
    return res.json({
      success: true,
      printed: false,
      message: 'No printer — report logged to console',
      report: text,
    });
  }

  try {
    const rawData = formatReportRaw(reportData);

    if (isWindows) {
      await printViaWindows(rawData, token);
    } else {
      await printViaCUPS(rawData, token);
    }

    await new Promise(r => setTimeout(r, PHYSICAL_PRINT_DELAY_MS));
    console.log(`🖨️ Report printed → ${printerName}`);
    res.json({ success: true, printed: true });
  } catch (err) {
    console.error('❌ Report print failed:', err.message);
    res.status(500).json({ success: false, error: err.message, report: text });
  }
});

// ── START ──────────────────────────────────────────────────────────
function start() {
  console.log(`\n🖨️ BytePrinter v4.1.0 (${os.platform()})`);
  console.log('─'.repeat(48));

  detectPrinter();

  http.createServer(app).listen(HTTP_PORT, '0.0.0.0', () => {
    console.log(`\n🚀 HTTP  → http://localhost:${HTTP_PORT}`);
  });
  console.log(`\n   GET  /status  → printer status`);
  console.log(`   POST /print   → print receipt`);

  if (isConnected) {
    console.log(`\n✅ Printer ready: ${printerName}`);
  } else {
    console.log('\n💡 No printer detected — receipts print to console.');
  }

  console.log('─'.repeat(48) + '\n');
}

start();
